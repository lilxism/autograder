import random

class PairOfDice:
	def __init__(self):
		self._dice1 = 0
		self._dice2 = 0
	def getDice1(self):
		return self._dice1
	def getDice2(self):
		return self._dice2
	def roll(self):
		self._dice1 = random.choice(range(1,7))
		self._dice2 = random.choice(range(1,7))
	def sum(self):
		return self._dice1 + self.dice2
		
def twoPlayers():
	player1 = PairOfDice()
	player2 = PairOfDice()
	
	player1.roll()
	player2.roll()
	
	p1_roll = player1.getDice1() + player1.getDice2()	
	p2_roll = player2.getDice1() + player2.getDice2()
	
	print("Player 1: ", p1_roll)
	print("Player 2: ", p2_roll)
	if (p1_roll > p2_roll):
		print("Player 1 wins.")
	elif (p1_roll < p2_roll):
		print("Player 2 wins.")
	else:
		print("Tie.")
		
twoPlayers()

def gotDouble(player, num):
	player.roll()
	if (player.getDice1() == num) and (player.getDice2() == num):
		return True
		
def doubleSix(throws, trials):
	wins = 0;
	for i in range(trials):
		player = PairOfDice()
		for j in range(throws):
			if gotDouble(player, 6):
				wins += 1
				break
	return (wins / trials)

print(doubleSix(24,10000))

