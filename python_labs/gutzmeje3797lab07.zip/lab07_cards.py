import random

'''This class represents a Playing card '''
class PlayingCard:
	def __init__(self, rank="queen", suit="hearts"):
		'''Creates a representation of a card - rank and suit'''
		self._rank = rank
		self._suit = suit
	
	def setRank(self, rank):
		'''sets the rank of card'''
		self._rank = rank
	
	def setSuit(self, suit):
		'''sets the suit of the card'''
		self._suit = suit
	
	def getRank(self):
		'''returns the rank of the card'''
		return self._rank
	
	def getSuit(self):
		'''returns the suit of the card'''
		return self._suit

	def selectAtRandom(self):
		'''sets the rank and suit to a random card'''
		#Randomly select a rank and a suit.
		ranks = ['2', '3', '4', '5', '6', '7', '8', '9', "10", "jack", "queen", "king", "ace"]
		self._rank = random.choice(ranks)
		self._suit = random.choice(["spades", "hearts", "clubs", "diamonds"])
	
	def __str__(self):
		'''returns string represtation of card'''
		return(self._rank + " of " + self._suit)
		
def main():
	
	cardList = []
	for i in range(13):
		card = PlayingCard()
		card.selectAtRandom()
		str = card.__str__()
		arr = str.split()
		cardList.append(arr)
	
	cardList.sort(key=lambda x: x[2], reverse=True)
	
	for card in cardList:
		print(card[0] + " " + card[1] + " " + card[2])
	
main()