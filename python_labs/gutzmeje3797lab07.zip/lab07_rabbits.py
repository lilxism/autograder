import random

class Rabbit:
	def __init__(self, sex):
		self.age = 0
		self.sex = sex
		self.dueDate = -1
	def getAge(self):
		return self.age
	def getSex(self):
		return self.sex
	def getDueDate(self):
		return self.dueDate
		
	def increaseAge(self):
		self.age += 1
		if (self.age == self.dueDate):
			return self.litter()
		if ((self.age == 100) and (self.sex == "f")):
			self.dueDate = self.age + random.choice(range(28,32))
			
	def litter(self):
		litterSize = random.choice(range(3,8))
		litter = set()
		for i in range(litterSize):
			if (random.choice(range(0,2)) == 1):
				litter.update({Rabbit("f")})
			else:
				litter.update({Rabbit("m")})
		
		self.dueDate = self.age + random.choice(range(28,32)) + 7
		#print(litter)
		return litter
		
def rabbitsMultiply(trials):
	import numpy as np
	
	totalMales = 0
	totalFemales = 0
	maleList = []
	femaleList = []
	totalList = []
	for t in range(trials):
		rabbitPopulation = {Rabbit("m"), Rabbit("f"), Rabbit("f")}
		for i in range(365):
			totalLitter = set()
			for rabbit in rabbitPopulation:
				litter = rabbit.increaseAge()
				if litter:
					totalLitter.update(litter)
			rabbitPopulation.update(totalLitter)
			
		males = 0
		females = 0
		for rabbit in rabbitPopulation:
			if rabbit.sex == "m":
				males += 1
			else:
				females += 1
		totalMales += males
		maleList.append(males)
		totalFemales += females
		femaleList.append(females)
		totalList.append(males + females)
		
		print("Trial ",t,": ",len(rabbitPopulation),"rabbits, ",females,"females,",males," males.")
	
	avg = (totalFemales+totalMales)/trials
	std = np.std(totalList)
	avgf = totalFemales/trials
	stdf = np.std(femaleList)
	avgm = totalMales/trials
	stdm = np.std(maleList)
	print("Average number of rabbits: ", avg, " with std of ", std)
	print("Average number of female rabbits: ", avgf, " with std of ", stdf)
	print("Average number of male rabbits: ", avgm, " with std of ", stdm)
	#print(((totalFemales+totalMales)/trials), ", ", (totalFemales/trials), ", ", (totalMales/trials))
	
rabbitsMultiply(10)