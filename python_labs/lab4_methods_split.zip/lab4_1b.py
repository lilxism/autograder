# Activity 1b
def main():
	y = int(input("Enter your year: "))
	print(determineRank(y))
	
def determineRank(years):
	rank_dict = {
		1: "Freshman",
		2: "Sophomore",
		3: "Junior"
	}
	
	return rank_dict.get(years, "Senior")

main()