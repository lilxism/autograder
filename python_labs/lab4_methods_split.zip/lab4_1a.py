# Activity 1a
def main():
	pres = input("Who was the youngest U.S. president? ")
	pres = pres.upper()
	isYoungest(pres)

def tr_message():
	print("Correct. He became president at the age of 42")
	print("when President McKinley was assasinated.")

def jfk_message():
	print("Incorrect. He became president at age of 43. However,")
	print("he was the youngest person elected president.")
	
def isYoungest(pres):
	tr_dict = {
		"THEODORE ROOSEVELT": tr_message,
		"TEDDY ROOSEVELT": tr_message,
		"TR": tr_message,
		"JFK": jfk_message,
		"JOHN KENNEDY": jfk_message,
		"JOHN F. KENNEDY": jfk_message
	}
	function = tr_dict.get(pres)
	try:
		function()
	except:
		print("Nope!")

main() 