# Activity 0
def main():
	list1 = [1,1,2,3,4,4,5,5,]
	list2 = [1,3,5, 6]
	print(removeDuplicates(list1))
	print()
	print(findItemsInBoth(list1,list2))
	print()
	print(findItemsInEither(list1, list2))

def removeDuplicates(list1):
	set1 = set(list1)
	return list(set1)

def findItemsInBoth(list1, list2):
	set1 = set(list1)
	set2 = set(list2)
	set3 = set1.intersection(set2)
	return list(set3)
	
def findItemsInEither(list1, list2):
	set1 = set(list1)
	set2 = set(list2)
	set1.update(set2)
	return list(set1)
	
main() 














