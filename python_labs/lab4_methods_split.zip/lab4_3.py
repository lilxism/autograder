# Activity 3
def main():
	topHitters = {"Gehrig":{"atBats":8061, "hits":2721},
					"Ruth":{"atBats":8399, "hits":2873},
					"Williams":{"atBats":7706, "hits":2654}}
	
	average(topHitters)
 
def average(topHitters):	
	for name, stats_dict in topHitters.items():
		average = stats_dict.get("hits") / stats_dict.get("atBats")
		print("{0:10} {1:.3f}" .format(name, average))
	
main()